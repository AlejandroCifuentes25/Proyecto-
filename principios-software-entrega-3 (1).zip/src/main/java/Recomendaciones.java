public class Recomendaciones {
    private String Recomendacion1;
    private String Recomendacion2;
    private String Recomendacion3;

    public Recomendaciones() {

    }

    public void CompararConPromedio(int consumo) {
        if (consumo > 1000) {
            Recomendacion1 = "Reducir el tiempo de la ducha para ahorrar agua.";
        }
        if (consumo > 2000) {
            Recomendacion2 = "Reparar cualquier fuga de agua en grifos o tuberías.";
        }
        if (consumo > 3000) {
            Recomendacion3 = "Utilizar dispositivos de bajo flujo en los grifos y la ducha.";
        }
    }

    public String getRecomendacion1() {
        return Recomendacion1;
    }

    public String getRecomendacion2() {
        return Recomendacion2;
    }

    public String getRecomendacion3() {
        return Recomendacion3;
    }
}
