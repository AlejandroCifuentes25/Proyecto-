import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class GuardarResultado {

    public static void AgregarDatos(int C1,String P, int D, int M, boolean consumoAlto) {

        File f = new File("HistorialDeConsumo.txt");
        FileWriter writer = null;
        PrintWriter pw = null;

        try {
            f.createNewFile();            
        } catch(IOException exception) {
            System.err.println("Error creando el archivo");
        }             

        try {
            writer = new FileWriter("HistorialDeConsumo.txt", true);
            pw = new PrintWriter(writer);
            pw.println("dia y mes"+":" +  D +"-"+ M + " " + C1 +" Litros de agua" + " - " + P + " - Consumo " + (consumoAlto ? "alto" : "bajo"));
        } catch(IOException exception) {
            System.err.println("Error abriendo el archivo");
        } finally {
            try {
                if (null != writer)
                    writer.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
}
